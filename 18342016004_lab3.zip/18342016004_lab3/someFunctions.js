function addFavs (){
    alert("Item uccessfully added to your favorites");
}

function validateForm(){
    let userName = document.forms["logInForm"]["username"].value;
    let password = document.forms["logInForm"]["password"].value;
    if (userName == "" || password == "") {
        alert("Username & password must be filled out");
        return false;
    }
}
